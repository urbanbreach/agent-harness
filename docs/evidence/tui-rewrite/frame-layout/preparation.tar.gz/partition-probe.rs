use ratatui::layout::{Constraint::{Length,Min},Layout,Rect};
fn main() {
 for (top,bottom) in [(0,0),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(3,3)] {
  for height in 0..=7 {
   let rect=Rect::new(4,9,12,height);
   let rows=Layout::vertical([Length(top),Min(0),Length(bottom)]).split(rect);
   println!("{top}/{bottom}/{height}: {:?}",rows.iter().map(|r|r.height).collect::<Vec<_>>());
  }
 }
 for rect in [Rect::new(65530,65530,12,12), Rect{x:65530,y:65530,width:12,height:12},Rect::new(2,4,0,5)] {
  println!("rect {rect:?}: {:?}",Layout::vertical([Min(0),Length(3)]).split(rect));
 }
}
