from pathlib import Path
import hashlib,json,shutil,subprocess
out=Path(__file__).resolve().parent
command=['cargo','rustc','--release','-p','harness-tui','--all-features','--test','rewrite_performance_test','--message-format=json','--','-C','strip=none']
with (out/'build-profile.jsonl').open('w') as data,(out/'build-profile.log').open('w') as log:
 subprocess.run(command,stdout=data,stderr=log,check=True)
artifacts=[json.loads(line) for line in (out/'build-profile.jsonl').read_text().splitlines()]
artifact=next(x for x in artifacts if x.get('reason')=='compiler-artifact' and x['target']['name']=='rewrite_performance_test')
saved=out/'profile.bin';shutil.copy2(artifact['executable'],saved)
metadata=json.loads(Path('/tmp/tui-composer-rows/candidate/binaries.json').read_text())
next(iter(metadata['rust-binaries'].values()))['binary-path']=str(saved)
(out/'profile-binaries.json').write_text(json.dumps(metadata,indent=2)+'\n')
receipt={'purpose':'Allocation stack diagnosis only; timing results are not acceptance evidence.','command':command,'sha256':hashlib.sha256(saved.read_bytes()).hexdigest(),'source_receipt':json.loads(Path('/tmp/tui-composer-rows/candidate/binary.json').read_text()),'base_patch_sha256':hashlib.sha256(Path('/tmp/tui-composer-rows/source.patch').read_bytes()).hexdigest()}
(out/'profile-binary.json').write_text(json.dumps(receipt,indent=2)+'\n')
