from pathlib import Path
import hashlib,json,subprocess
out=Path('/tmp/tui-runtime-state')
paths=['crates/harness-tui/src/ui_chrome.rs','crates/harness-tui/src/ui_live_turn_status.rs','crates/harness-tui/src/runtime_integration.rs','crates/harness-tui/src/lib_tests/permission_runtime.rs','crates/harness-tui/src/lib_tests/runtime_review_surface.rs']
receipts=[]
for name in paths:
 data=Path(name).read_bytes()
 assert data==subprocess.check_output(['git','show','HEAD:'+name])
 receipts.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
(out/'baseline-source-addendum.json').write_text(json.dumps(receipts,indent=2)+'\n')
p=Path(paths[3]);s=p.read_text()
s=s.replace('assert_eq!(ready.runtime_state().kind, app::RuntimeStateKind::Ready);','assert_runtime_state(&ready, app::RuntimeStateKind::Ready, "ready for first turn", None, false, "Type a prompt for the next turn…");')
s=s.replace('assert_eq!(sending.runtime_state().kind, app::RuntimeStateKind::Sending);','assert_runtime_state(&sending, app::RuntimeStateKind::Sending, "turn 1 · response starting", None, false, "Draft the next prompt while the response starts…");')
s=s.replace('''    assert_eq!(
        sending.runtime_state().kind,
        app::RuntimeStateKind::Streaming
    );''','''    assert_runtime_state(&sending, app::RuntimeStateKind::Streaming, "turn 2 · response in progress", None, false, "Draft the next prompt while the response continues…");''')
s=s.replace('''    assert!(!matches!(
        sending.runtime_state().kind,
        app::RuntimeStateKind::Sending | app::RuntimeStateKind::Streaming
    ));''','''    assert_runtime_state(&sending, app::RuntimeStateKind::Success, "turn 2 · ready for next turn", None, false, "Type a prompt for the next turn…");''')
s=s.replace('''    assert_eq!(
        cancelled.runtime_state().kind,
        app::RuntimeStateKind::Cancelled
    );''','''    assert_runtime_state(&cancelled, app::RuntimeStateKind::Cancelled, "last turn cancelled · operator cancelled", Some("operator cancelled"), false, "Type a prompt to retry the cancelled turn…");''')
s=s.replace('    assert_permission_and_connection_status_strips();','    assert_permission_and_connection_status_strips();\n    assert_tool_runtime_states();')
s=s.replace('    let permission_blocked_debug =', '''    assert_runtime_state(&permission_blocked, app::RuntimeStateKind::PermissionBlocked, "decision required · Apply hashline edit to demo.txt", Some("Apply hashline edit to demo.txt"), false, "Draft preserved under the checkpoint — deny stays fail-closed; allow once only after review.");
    let permission_blocked_debug =''')
s=s.replace('    let permission_pending_debug =', '''    assert_runtime_state(&permission_blocked, app::RuntimeStateKind::PermissionPending, "decision submitted · awaiting confirmation · Apply hashline edit to demo.txt", Some("Apply hashline edit to demo.txt"), true, "Draft preserved while Harness records the decision. Wait for confirmation before sending again.");
    let permission_pending_debug =''')
s+='''
fn assert_runtime_state(app: &app::AppState, kind: app::RuntimeStateKind, summary: &str, detail: Option<&str>, disabled: bool, hint: &str) {
    assert_eq!(app.runtime_state(), app::RuntimeState {
        kind, summary: summary.to_string(), detail: detail.map(str::to_string),
        composer_disabled: disabled, composer_hint: hint.to_string(),
    });
    assert_eq!(app.composer_disabled(), disabled);
}

fn assert_tool_runtime_states() {
    use harness_core::event::{EventV1, ToolCallMetadata, ToolCallStatus};
    for (count, failed, kind, summary, detail, hint) in [
        (7, false, app::RuntimeStateKind::Streaming, "tool queued · agent.spawn", "inspect", "Draft the next prompt while the queued tool waits to start…"),
        (8, false, app::RuntimeStateKind::Streaming, "tool running · agent.spawn", "inspect", "Draft the next prompt while the tool runs…"),
        (9, false, app::RuntimeStateKind::Streaming, "tool finished · waiting for final response · agent.spawn", "tool output", "Draft the next prompt while the assistant finishes after the tool result…"),
        (9, true, app::RuntimeStateKind::Failure, "tool failed · agent.spawn", "tool output", "After review, adjust the draft, then retry or continue."),
    ] {
        let mut app = app::AppState::new_live(None, false, None);
        for mut event in session_view_events().into_iter().take(count) {
            match &mut event.payload {
                EventV1::ToolCallRequested(tool) => {
                    tool.tool_id = "task".to_string();
                    tool.args_summary = "inspect".to_string();
                    tool.metadata = Some(ToolCallMetadata {
                        canonical_tool_id: Some("agent.spawn".to_string()),
                        alias_source_tool_id: Some("task".to_string()),
                        ..ToolCallMetadata::default()
                    });
                }
                EventV1::ToolCallFinished(tool) if failed => tool.status = ToolCallStatus::Failed,
                _ => {}
            }
            app.ingest_event(event);
        }
        assert_runtime_state(&app, kind, summary, Some(detail), false, hint);
    }
}
'''
p.write_text(s)
p=Path(paths[4]);s=p.read_text();needle='''    assert!(ui::runtime_overlay_text_for_test(&app, 72).is_none());'''
s=s.replace(needle,'''    assert_eq!(app.runtime_state().kind, app::RuntimeStateKind::Degraded);
    assert!(app.runtime_state().composer_disabled);
    assert!(app.composer_disabled());
'''+needle,1);p.write_text(s)
