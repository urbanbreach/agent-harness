#!/usr/bin/env python3
import os,sys
if '--list' in sys.argv:
 os.execv(sys.argv[1],sys.argv[1:])
os.execvp('gdb',['gdb','--batch','-x','/tmp/tui-composer-paint/profile.gdb','--args',*sys.argv[1:]])
