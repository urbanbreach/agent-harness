from pathlib import Path
import shutil
out=Path(__file__).resolve().parent;root=Path('crates/harness-tui/src')
p=root/'ui_chrome.rs';s=p.read_text()
s=s.replace('completed_session_status_summary, composer_shortcut_hints, render_control_dock_disclosure,\n    render_replay_read_only_composer_content, replay_read_only_shortcut_hints, status_context,','completed_session_status_summary, render_control_dock_disclosure,\n    render_replay_read_only_composer_content,')
a=s.index('#[cfg(test)]\nuse self::ui_control_dock_disclosure::');b=s.index('\nconst QUIET_SURFACE',a)
s=s[:a]+'''struct ComposerRenderContext {
    startup: bool,
    focused: bool,
    disabled: bool,
    composer_lines: u16,
}
'''+s[b:]
a=s.index('    let dock = build_control_dock_view_model(app, theme);');b=s.index('\n    let active_permission',a)
s=s[:a]+'''    let startup = app.startup_shell_visible();
    if !startup {
        frame.render_widget(open_canvas(theme.surface.canvas), dock_layout.shell);
    }
    if !startup && app.replay_mode {
        render_replay_read_only_composer_content(frame, dock_layout.composer, app, theme);
        return;
    }
'''+s[b:]
s=s.replace('render_control_dock_disclosure(frame, disclosure_area, app, theme, &dock);','render_control_dock_disclosure(frame, disclosure_area, app, theme);')
s=s.replace('let composer_lines = if dock.variant == crate::view_model::ControlDockVariant::Startup {','let composer_lines = if startup {')
s=s.replace('            dock: &dock,','            startup,\n            focused: app.focus == Focus::Prompt,\n            disabled: app.composer_disabled(),')
a=s.index('fn build_control_dock_view_model(');b=s.index('fn control_dock_summary_segment(',a);s=s[:a]+s[b:]
a=s.index('fn render_control_dock_top_divider(');b=s.index('#[cfg(test)]',a);s=s[:a]+s[b:];p.write_text(s)
for name in ['bordered','collapsed']:
 p=root/f'ui_composer/{name}.rs';s=p.read_text().replace("ComposerRenderContext<'_>",'ComposerRenderContext').replace('context.dock.composer_focused','context.focused').replace('context.dock.composer_disabled','context.disabled').replace('context.dock.variant == crate::view_model::ControlDockVariant::Startup','context.startup');p.write_text(s)
p=root/'view_model.rs';s=p.read_text();a=s.index('#[derive(Debug, Clone, PartialEq, Eq)]\npub(crate) struct ControlDockViewModel');b=s.index('pub(crate) fn post_run_handoff_notice',a);s=s[:a]+s[b:];p.write_text(s)
p=root/'app/session_projection.rs';s=p.read_text();a=s.index('    pub fn runtime_context_primary_summary');b=s.index('    pub(crate) fn active_retry_metadata',a)
s=s[:a]+'''    pub fn runtime_context_primary_summary(&self) -> String {
        self.runtime_context_grammar().primary_summary
    }

    pub fn runtime_context_summary_segment_text(&self) -> Option<String> {
        self.runtime_context_summary_segment().map(|segment| segment.text)
    }

    pub fn runtime_context_provider_display(&self) -> Option<String> {
        self.runtime_provider_context()
    }

    pub(crate) fn runtime_context_summary_segment(&self) -> Option<view_model::ControlDockSummarySegment> {
        if self.startup_shell_visible() || self.replay_mode {
            None
        } else {
            self.cache_status_summary_segment().or_else(|| self.runtime_context_grammar().summary_segment)
        }
    }

    fn runtime_context_grammar(&self) -> view_model::RuntimeContextGrammar {
        view_model::runtime_context_grammar(view_model::RuntimeContextGrammarInput {
            label: self.runtime_context_label(),
            identity: self.runtime_context_identity(),
            next_turn_identity: self.next_turn_identity(),
        })
    }

'''+s[b:]
a=s.index('    pub(crate) fn control_dock_view_model');b=s.index('    pub(crate) fn operator_rail_has_sections',a);s=s[:a]+s[b:];p.write_text(s)
# Keep the replay compositor's separate body and clipping contract.
old=(out/'legacy/ui_control_dock_disclosure.rs').read_text()
a=old.index('pub(super) fn render_replay_read_only_composer_content(');b=old.index('pub(super) fn render_control_dock_disclosure(',a);replay=old[a:b]
replay=replay.replace('    theme: &Theme,\n    dock: &crate::view_model::ControlDockViewModel,','    app: &AppState,\n    theme: &Theme,').replace('let surface = control_dock_surface(theme, dock.variant);','''let surface = theme.surface.canvas;
    let runtime = app.runtime_state_view();
    let body = if runtime.kind == crate::app::RuntimeStateKind::Failure {
        match runtime.detail.as_deref().filter(|detail| !detail.trim().is_empty()) {
            Some(detail) => format!("Replay is read-only · {} · {detail}", runtime.summary),
            None => format!("Replay is read-only · {}", runtime.summary),
        }
    } else {
        "Replay is read-only.".to_string()
    };''').replace('&dock.composer_body','&body').replace('&dock.composer_disclosure','&replay_read_only_shortcut_hints(app)').replace('truncate_plain_text(','super::truncate_plain_text(')
a=old.index('pub(super) fn replay_read_only_shortcut_hints');b=old.index('#[cfg(test)]',a);tail=old[a:b].replace('RuntimeStateKind::Failure','crate::app::RuntimeStateKind::Failure')
s=(out/'disclosure.rs').read_text()+'\n'+replay+'\n'+tail
(root/'ui_control_dock_disclosure.rs').write_text(s)
folder=root/'ui_control_dock_disclosure';folder.mkdir(exist_ok=True)
for name in ['hints','summaries']:shutil.copy2(out/f'{name}.rs',folder/f'{name}.rs')

# These variant-only adapters have no remaining callers.
p=root/'ui_chrome.rs';s=p.read_text()
for start,end in [('pub(super) fn control_dock_surface(', 'pub(super) fn elevated_card_surface('), ('pub(super) fn unified_bottom_dock(', "pub(super) fn modal_card<'a>("), ('pub(super) fn control_dock_section(', "pub(super) fn secondary_pane_block<'a>(")]:
 a=s.index(start);b=s.index(end,a);s=s[:a]+s[b:]
s=s[:s.index('#[cfg(test)]\nmod surface_tests')];p.write_text(s)
p=root/'view_model.rs';s=p.read_text();a=s.index('#[derive(Debug, Clone, Copy, PartialEq, Eq)]\npub(crate) enum ControlDockVariant');b=s.index('#[derive(Debug, Clone, Copy, PartialEq, Eq)]\npub(crate) enum ControlDockSummarySegmentKind',a);s=s[:a]+s[b:];p.write_text(s)
