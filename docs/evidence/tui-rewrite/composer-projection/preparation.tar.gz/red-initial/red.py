from pathlib import Path
import json,subprocess
out=Path(__file__).resolve().parent
p=Path('crates/harness-tui/src/ui_composer/presentation.rs');current=p.read_bytes()
source=subprocess.check_output(['git','show','16ab0230547d73b0b9468eab683c880b920cda47:'+str(p)]).decode()
assert source.count('if actual.text() == text {')==1
command=['cargo','nextest','run','--profile','ci','-p','harness-tui','--all-features','--test','production_composer_reachability_test','--test','ghost_suggestion_render_test']
try:
 p.write_text(source.replace('if actual.text() == text {','if actual.text() == text && text.is_empty() {'))
 (out/'red.patch').write_bytes(subprocess.check_output(['git','diff','--',str(p)]))
 with (out/'red.log').open('w') as log: result=subprocess.run(command,stdout=log,stderr=log)
 (out/'red.json').write_text(json.dumps({'command':command,'exit':result.returncode},indent=2)+'\n')
 assert result.returncode==100
finally:p.write_bytes(current)
