from pathlib import Path
root=Path('crates/harness-tui/src')
p=root/'app/tests/model_context_tests.rs';s=p.read_text().replace('use crate::view_model;\n','')
for app,var in [('startup','startup_dock'),('live','live_dock'),('continued','continued_dock'),('replay','replay_dock'),('live','dock')]:
 s=s.replace(f'    let {var} = {app}.control_dock_view_model();\n','')
 for field,call in [('primary_summary','runtime_context_primary_summary()'),('summary_segment','runtime_context_summary_segment_text()'),('runtime_context','runtime_context_provider_display()'),('composer_disabled','composer_disabled()')]:s=s.replace(f'{var}.{field}',f'{app}.{call}')
s=s.replace('''Some(view_model::ControlDockSummarySegment {
            kind: view_model::ControlDockSummarySegmentKind::Orchestration,
            text: "Next turns: GPT-5.4 Mini · Creative".to_string(),
            tone: view_model::ControlDockSummaryTone::Secondary,
        })''','''Some("Next turns: GPT-5.4 Mini · Creative".to_string())''')
p.write_text(s)
p=root/'app/tests/activity_lifecycle_tests.rs';s=p.read_text().replace('''let segment = app
        .control_dock_view_model()
        .summary_segment
        .unwrap_or_abort();
    assert_eq!(segment.text, "cache read 41 · write 17");''','''assert_eq!(app.runtime_context_summary_segment_text().as_deref(), Some("cache read 41 · write 17"));''');p.write_text(s)
p=root/'app/tests/render_purity_tests.rs';s=p.read_text().replace('let _dock = app.control_dock_view_model();','let _summary = app.runtime_context_primary_summary();').replace('let first_dock = app.control_dock_view_model();','let first_render = render_debug(&app, 120, 40);').replace('''app.control_dock_view_model(),
        first_dock,
        "control-dock view model must be stable across repeated reads"''','''render_debug(&app, 120, 40),
        first_render,
        "rendered buffer must be stable across repeated reads"''');p.write_text(s)
