from pathlib import Path
import shutil
out=Path(__file__).resolve().parent
s=Path('/tmp/tui-frame-layout/oracle-cases.rs').read_text().replace('frozen_frame_plan_matches_replacement','dock_render_reference')
s=s.replace('    let mut custom=Theme::default();', '''    for active in [false, true] {
      for draft in ["", "draft 界👩‍💻", "first\\nsecond"] {
        let mut app=if active {waiting_app()} else {completed_app()};
        app.composer.prompt_buffer=draft.into();
        apps.push(app);
      }
    }
    for count in [0, 2] {
      let mut app=completed_app();
      app.projection.compaction_usage_metrics=crate::app::CompactionUsageMetrics {completed_count:count,summary_tokens_estimate:1400,reduction_tokens_estimate:12000,last_reduction_percent_estimate:Some(45),..Default::default()};
      app.projection.compaction_status=Some(crate::app::CompactionStatus {agent_id:"main".into(),checkpoint_id:None,trigger_reason:"test".into(),state:crate::app::CompactionState::Requested,message:"Compacting 界👩‍💻 context".into()});
      apps.push(app);
    }
    let mut app=completed_app();app.composer.prompt_buffer="clear me".into();
    app.handle_key(crossterm::event::KeyEvent::new(crossterm::event::KeyCode::Esc,crossterm::event::KeyModifiers::NONE));apps.push(app);
    let mut app=completed_app();app.todo_pane.visible=true;app.focus=crate::app::Focus::Todo;apps.push(app);
    let mut app=failed_app();app.replay_mode=true;apps.push(app);
    let mut custom=Theme::default();''')
s=s.replace('let themes=[Theme::default(),Theme::harness_light(),custom];','let themes=[Theme::default(),Theme::harness_light(),Theme::terminal_native(),custom];')
a=s.index('    let mut areas=Vec::new();')
s=s[:a]+'''    let path=std::env::var("HARNESS_DOCK_ORACLE_OUT").unwrap_or_abort();
    let mut output=std::io::BufWriter::new(std::fs::File::create(path).unwrap_or_abort());
    let mut cases=0;
    for (state,app) in apps.iter_mut().enumerate() {
      app.set_reduced_motion(true);
      for (theme_index,theme) in themes.into_iter().enumerate() {
        app.set_theme_for_test(theme);
        for width in [1,2,5,12,20,39,40,59,60,61,79,80,81,99,100,119,120,140,160] {
          for height in [6,20,40] {
            let mut terminal=ratatui::Terminal::new(ratatui::backend::TestBackend::new(width,height)).unwrap_or_abort();
            terminal.draw(|frame| crate::ui::render_app(frame,app)).unwrap_or_abort();
            let cells=format!("{:?}",terminal.backend().buffer().content);
            let cursor=terminal.backend_mut().get_cursor_position().unwrap_or_abort();
            let record=serde_json::json!({"state":state,"theme":theme_index,"width":width,"height":height,"cells":cells,"cursor":format!("{cursor:?}"),"context":[app.runtime_context_primary_summary(),app.runtime_context_summary_segment_text().unwrap_or_default(),app.runtime_context_provider_display().unwrap_or_default()]});
            writeln!(output,"{record}").unwrap_or_abort();cases+=1;
          }
        }
      }
    }
    println!("Recorded {cases} exact full styled buffers and cursors for {} states, {} themes, 57 dimensions.",apps.len(),themes.len());
}
'''
preamble='''use crate::{app::AppState, theme::Theme, UnwrapOrAbort};
use ratatui::backend::Backend;
use std::io::Write;
#[path = "/home/urbanbreach/Projects/agent-harness/crates/harness-tui/src/layout_live_dock_test_fixtures.rs"]
mod live_dock_test_fixtures;
'''
(out/'oracle.rs').write_text(preamble+s)
s=Path('/tmp/tui-frame-layout/nextest-oracle.toml').read_text().replace('frozen_frame_plan_matches_replacement','dock_render_reference')
(out/'nextest-oracle.toml').write_text(s)
