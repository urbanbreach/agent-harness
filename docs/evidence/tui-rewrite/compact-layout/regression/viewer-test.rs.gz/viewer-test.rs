use harness_tui::theme::Theme;
use harness_tui::transcript_block_viewer::{render_surface, render_to_buffer};
use harness_tui::transcript_block_viewer::{
    ViewerBlockContent, ViewerCloseReason, ViewerMode, ViewerReturnSnapshot, ViewerState,
};
use harness_tui::transcript_blocks::FoldState;
use harness_tui::transcript_identity::{BlockId, FocusFollowState, ReplayTurn, TranscriptFocus};
use harness_tui::transcript_scroll::{LogicalAnchor, TranscriptLayout};
use harness_tui::transcript_selection::{
    CellPoint, LocalPlatform, NavigationKey, TmuxSequence, Viewport,
};
use ratatui::buffer::Buffer;
use ratatui::layout::Rect;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error>>;

#[path = "support/rewrite_journey.rs"]
mod journey;

fn block_id() -> BlockId {
    ReplayTurn::event(41, 2, 1).block_id(0)
}

fn return_snapshot(id: BlockId) -> TestResult<ViewerReturnSnapshot> {
    let layout = TranscriptLayout::from_heights([(id, 12.0)], 5.0)?;
    let anchor = LogicalAnchor::capture(&layout, 3.25)?;
    Ok(ViewerReturnSnapshot::new(
        FoldState::Collapsed,
        FocusFollowState::new(TranscriptFocus::Timeline, false),
        anchor,
    ))
}

fn viewer(text: &str) -> TestResult<ViewerState> {
    Ok(ViewerState::open(
        block_id(),
        ViewerBlockContent::new(text, Some(text)),
        return_snapshot(block_id())?,
    )?)
}

#[test]
fn search_wraps_back_and_forward_and_reports_no_result() -> TestResult {
    // arrange
    // Given: a selected block with two Unicode matches.
    let mut viewer = viewer("中 alpha 中")?;

    // When: the query is entered and navigated in both directions.
    let first = viewer.set_search_query("中");
    let forward = viewer.search_forward();
    let forward_wrap = viewer.search_forward();
    let backward_wrap = viewer.search_backward();
    let absent = viewer.set_search_query("missing");

    // act
    // Then: count, current match, wrap, and no-result state are explicit.
    // assert
    assert_eq!(first.match_count, 2);
    assert_eq!(first.current_match, Some(0));
    assert!(!forward.wrapped);
    assert_eq!(forward.current_match, Some(1));
    assert!(forward_wrap.wrapped);
    assert_eq!(forward_wrap.current_match, Some(0));
    assert!(backward_wrap.wrapped);
    assert_eq!(backward_wrap.current_match, Some(1));
    assert!(absent.no_result);
    assert_eq!(absent.match_count, 0);
    Ok(())
}

#[test]
fn search_accepts_complete_unicode_graphemes_and_rejects_partial_ones() -> TestResult {
    // A spacing mark shares a grapheme but still occupies its own terminal cell.
    let mut spacing = viewer("कःX")?;
    spacing.set_search_query("X");
    let area = Rect::new(0, 0, 40, 12);
    let mut buffer = Buffer::empty(area);
    render_to_buffer(
        &mut buffer,
        area,
        &spacing.render_surface(area),
        &Theme::harness_dark(),
    );
    let marker = buffer
        .content
        .iter()
        .find(|cell| cell.symbol() == "X")
        .ok_or("missing painted marker")?;
    assert!(marker.modifier.contains(ratatui::style::Modifier::REVERSED));
    spacing.mouse_drag(
        CellPoint::new(0, 2),
        CellPoint::new(0, 2),
        Viewport::new(0, 1),
    )?;
    assert_eq!(spacing.copy_selection_text()?, "X");

    // arrange
    // Given: combining text, a ZWJ emoji, and CJK content.
    let mut viewer = viewer("e\u{301} 👩‍💻 中 \u{1100}\u{1161}\u{11a8}")?;

    // When: complete clusters and an incomplete cluster are searched.
    let combining = viewer.set_search_query("e\u{301}");
    let emoji = viewer.set_search_query("👩‍💻");
    let partial = viewer.set_search_query("\u{301}");

    // act
    // Then: complete graphemes match while a combining suffix cannot be split.
    // assert
    assert_eq!(combining.match_count, 1);
    assert_eq!(emoji.match_count, 1);
    assert!(partial.no_result);
    assert_eq!(
        viewer
            .set_search_query("\u{1100}\u{1161}\u{11a8}")
            .match_count,
        1
    );
    assert!(viewer.set_search_query("\u{1161}").no_result);
    Ok(())
}

#[test]
fn wrapped_and_raw_modes_route_selection_through_transcript_primitives() -> TestResult {
    // arrange
    // Given: a narrow viewer so the wrapped selection crosses a soft row.
    let mut viewer = viewer("alpha beta\ngamma")?;
    viewer.resize(6, 3)?;

    // When: word, keyboard, and mouse selections are made in each mode.
    let word = viewer.select_word(CellPoint::new(0, 1));
    assert_eq!(viewer.copy_selection_text()?, "alpha");
    assert_eq!(Some(word), viewer.selection());
    viewer.move_cursor(NavigationKey::Right, false);
    viewer.move_cursor(NavigationKey::Right, true);
    let mouse = viewer.mouse_drag(
        CellPoint::new(0, 0),
        CellPoint::new(1, 4),
        Viewport::new(0, 2),
    )?;
    assert_eq!(viewer.copy_selection_text()?, "alpha beta");
    assert_eq!(mouse.focus.row, 1);
    viewer.toggle_mode()?;
    assert_eq!(viewer.mode(), ViewerMode::Raw);
    viewer.select_line(CellPoint::new(2, 1));

    // act
    // Then: raw selection remains grapheme-safe and is copied through the same primitive.
    // assert
    assert_eq!(viewer.copy_selection_text()?, "gamma");
    Ok(())
}

#[test]
fn denied_copy_is_typed_and_non_destructive_for_local_and_osc52_routes() -> TestResult {
    // arrange
    // Given: an active selection.
    let mut viewer = viewer("copy me")?;
    viewer.select_line(CellPoint::new(0, 0));
    let before = viewer.selection();

    // When: both clipboard routes are denied.
    let local = viewer.copy_local_with_runner(
        LocalPlatform::Linux { wayland: false },
        |_command, _text| Ok(false),
    );
    let osc52 = viewer.copy_osc52(false, TmuxSequence::Direct);

    // act
    // Then: errors are typed and the selection is unchanged.
    // assert
    assert!(local.is_err());
    assert!(osc52.is_err());
    assert_eq!(viewer.selection(), before);
    Ok(())
}

#[test]
fn viewer_scroll_is_independent_and_survives_resize_with_anchor_identity() -> TestResult {
    // arrange
    // Given: content taller than the viewer viewport.
    let mut viewer = viewer("one two three four five six seven eight")?;
    viewer.resize(7, 2)?;

    // When: the viewer scrolls, animates, and is resized.
    viewer.scroll_by(3.0)?;
    let before = viewer.scroll_anchor()?;
    viewer.resize(14, 4)?;
    let frame = viewer.sample_scroll(500);

    // act
    // Then: viewer scroll state uses its own stable block anchor and settles safely.
    // assert
    assert_eq!(before.block_id(), block_id());
    assert_eq!(viewer.scroll_anchor()?.block_id(), block_id());
    assert!(frame.value >= 0.0);

    // Large recorded output must reach its real tail beyond u16 scroll offsets.
    let content = format!("{}tail-after-65535", "recorded row\n".repeat(70_000));
    let mut large = ViewerState::open(
        block_id(),
        ViewerBlockContent::new(&content, Some(&content)),
        return_snapshot(block_id())?,
    )?;
    large.resize(70, 17)?;
    large.scroll_by(100_000.0)?;
    let area = Rect::new(0, 0, 80, 24);
    let mut buffer = Buffer::empty(area);
    render_to_buffer(
        &mut buffer,
        area,
        &large.render_surface(area),
        &Theme::harness_dark(),
    );
    let painted = buffer
        .content
        .iter()
        .map(|cell| cell.symbol())
        .collect::<String>();
    assert!(painted.contains("tail-after-65535"));
    Ok(())
}

#[test]
fn closing_restores_fold_focus_follow_and_anchor_exactly() -> TestResult {
    // arrange
    // Given: an in-place state captured before entering the viewer.
    let snapshot = return_snapshot(block_id())?;
    let viewer = ViewerState::open(
        block_id(),
        ViewerBlockContent::new("selected", None),
        snapshot,
    )?;

    // When: the full-screen viewer closes.
    let closed = viewer.close();

    // act
    // Then: the complete return snapshot is byte-for-byte equivalent.
    // assert
    assert_eq!(closed.reason(), ViewerCloseReason::Closed);
    assert_eq!(closed.return_snapshot(), snapshot);
    Ok(())
}

#[test]
fn disappearing_block_closes_safely_without_losing_return_state() -> TestResult {
    // arrange
    // Given: an open viewer for a currently present block.
    let snapshot = return_snapshot(block_id())?;
    let mut viewer = ViewerState::open(
        block_id(),
        ViewerBlockContent::new("selected", None),
        snapshot,
    )?;

    // When: compaction or deletion reports that the block is gone.
    let closed = viewer
        .reconcile_block(false)
        .ok_or("viewer did not close")?;

    // act
    // Then: the viewer is inactive and returns the original state safely.
    // assert
    assert!(!viewer.is_open());
    assert_eq!(closed.reason(), ViewerCloseReason::BlockDisappeared);
    assert_eq!(closed.return_snapshot(), snapshot);
    Ok(())
}

#[test]
fn wrapped_and_raw_render_surfaces_highlight_current_match_and_selection() -> TestResult {
    // arrange
    // Given: a viewer with a selected line and an active search match.
    let mut viewer = viewer("alpha beta")?;
    viewer.select_line(CellPoint::new(0, 1));
    viewer.set_search_query("beta");
    let area = Rect::new(0, 0, 40, 12);
    viewer.resize(34, 4)?;

    // When: both rendering modes are materialized into a terminal buffer.
    let wrapped = render_surface(&viewer, area);
    let mut buffer = Buffer::empty(area);
    render_to_buffer(&mut buffer, area, &wrapped, &Theme::harness_dark());
    viewer.toggle_mode()?;
    let raw = viewer.render_surface(area);

    // act
    // Then: mode labels and match/selection state survive the render boundary.
    // assert
    assert_eq!(wrapped.mode, ViewerMode::Wrapped);
    assert!(wrapped.lines[0].selected);
    assert!(wrapped.lines[0].current_match);
    assert_eq!(raw.mode, ViewerMode::Raw);
    assert!(buffer.content.iter().any(|cell| cell.symbol() == "b"));
    assert_eq!(buffer[(0, 1)].fg, ratatui::style::Color::Rgb(88, 88, 88));
    Ok(())
}

#[test]
fn searching_long_unwrapped_output_keeps_its_tail_reachable() -> TestResult {
    use crossterm::event::{KeyCode, KeyModifiers};
    use harness_tui::{app::Focus, ui::render_app};
    use ratatui::{backend::TestBackend, Terminal};
    use serde_json::json;

    let workspace = tempfile::tempdir()?;
    std::env::set_current_dir(workspace.path())?;
    let mut j = journey::Journey::new(false);
    j.start("turn", "Inspect recorded output")?;
    let output = format!("{}\n{}end-row", "a".repeat(20_000), "z\n".repeat(64));
    j.event("tool_call_requested", json!({"tool_call_id":"long-output", "tool_id":"bash",
        "args_summary":"{\"command\":\"printf fixture\"}", "args_digest":"fixture", "metadata":null}))?;
    j.event(
        "provider_request_finished",
        json!({"request_id":"turn", "finish_reason":"tool_calls",
        "output_digest":null,"usage":null,"metadata":null}),
    )?;
    j.event("tool_call_started", json!({"tool_call_id":"long-output"}))?;
    j.event(
        "tool_call_finished",
        json!({"tool_call_id":"long-output", "status":"succeeded",
        "output_summary":output,"output_digest":null,
        "output_json":{"stdout":output,"stderr":"","exit_code":0},"metadata":null}),
    )?;
    let area = Rect::new(0, 0, 80, 32);
    let mut terminal = Terminal::new(TestBackend::new(area.width, area.height))?;
    j.app.set_frame_area(area);
    terminal.draw(|frame| render_app(frame, &j.app))?;
    j.app.focus = Focus::Details;
    assert!(j.app.select_transcript_tool("long-output"));
    for key in [
        KeyCode::Enter,
        KeyCode::Char('w'),
        KeyCode::Char('/'),
        KeyCode::Char('a'),
        KeyCode::Enter,
        KeyCode::End,
    ] {
        j.key(key, KeyModifiers::NONE);
    }
    j.app.set_frame_area(area);
    // Offscreen matches must not make a short tail frame stall past the nextest deadline.
    let painted = terminal.draw(|frame| render_app(frame, &j.app))?;
    let text = painted
        .buffer
        .content
        .iter()
        .map(|cell| cell.symbol())
        .collect::<String>();
    assert!(text.contains("[search: a]") && text.contains("end-row"));
    assert!(!text.contains("aaaa"));
    j.key(KeyCode::Esc, KeyModifiers::NONE);
    j.key(KeyCode::Esc, KeyModifiers::NONE);
    assert!(j.app.transcript_viewer_mode().is_none());
    Ok(())
}
