use std::collections::{BTreeMap, VecDeque};

use harness_core::event::{
    ActorKind, ProviderRequestStartedEvent, ToolCallLifecycleState, UserMessageSubmittedEvent,
};
use harness_core::session::{
    CanonicalLegacyCompaction, CanonicalLegacyCompactionStatus, CanonicalProviderFragmentKind,
};
use harness_core::transcript_projection::{
    CompactionCheckpointStatus, ProjectedMessageRole, ProjectedMessageState, ProjectedPart,
    ProjectedPermissionPart, ProjectedPermissionState, ProjectedTaskState, ProjectedToolCallPart,
    ProjectedToolCallState, SessionLineageProjection,
};

use super::*;
use crate::app::permissions::PermissionEntry;
use crate::app::{TaskLineageEntry, ToolArtifactEntry};

mod canonical_orchestration;
mod canonical_provider;
mod compaction;
mod parts;
mod presentation_merge;
mod suffix;
mod tasks;

use self::canonical_orchestration::*;
use self::canonical_provider::*;
use self::parts::*;
use self::presentation_merge::*;
use self::tasks::*;

impl SessionProjection {
    pub(super) fn rebuild_settled_presentation(&mut self, inline: bool, from: usize) {
        // An inline child is a display slice, not a complete durable log. Keep
        // its original sequence numbers and use the transcript projector,
        // which accepts ordered slices without weakening history validation.
        let inline_projection;
        let (events, transcript, run_summary) = if inline {
            let events = self.inspection_events.as_deref().unwrap_or_default();
            inline_projection = match (
                harness_core::transcript_projection::project_transcript(events),
                harness_core::proj::project_run_summary(events),
            ) {
                (Ok(transcript), Ok(summary)) => (transcript, summary),
                (Err(error), _) => {
                    self.canonical_projection_error = Some(error.to_string());
                    return;
                }
                (_, Err(error)) => {
                    self.canonical_projection_error = Some(error.to_string());
                    return;
                }
            };
            (events, &inline_projection.0, &inline_projection.1)
        } else {
            let Some(canonical) = self.canonical_projection.as_ref() else {
                return;
            };
            (
                canonical.source_events(),
                &canonical.transcript,
                &canonical.run_summary,
            )
        };
        let active_events = if from == 0 {
            harness_core::conversation_rewind::active_events(events)
        } else {
            std::borrow::Cow::Borrowed(events)
        };
        let events = active_events.as_ref();
        let legacy_compaction = harness_core::session::legacy::latest_legacy_compaction(events);
        let cutoff = if from == 0 {
            0
        } else {
            self.activities[from].first_seq
        };
        let events = &events[events.partition_point(|event| event.seq < cutoff)..];
        let mut prefix = std::mem::take(&mut self.activities);
        let presentation_enrichment = prefix.split_off(from);
        let (mut orchestration_tasks, presentation_orchestration): (BTreeMap<_, _>, _) =
            std::mem::take(&mut self.orchestration_tasks)
                .into_iter()
                .partition(|(_, row)| row.first_seq < cutoff);
        let mut settled_activities = VecDeque::new();
        let mut activity_by_request = BTreeMap::new();
        let mut pending_permissions = std::mem::take(&mut self.pending_permissions);
        pending_permissions.retain(|_, permission| permission.seq < cutoff);
        let mut turn_terminals = BTreeMap::new();

        let at = transcript
            .messages
            .partition_point(|message| message.provenance.first_seq < cutoff);
        for message in &transcript.messages[at..] {
            let request_id = message
                .request_id
                .as_ref()
                .map_or_else(|| message.message_id.clone(), ToString::to_string);
            let activity_index = match message.role {
                ProjectedMessageRole::User => {
                    let text = message
                        .parts
                        .iter()
                        .filter_map(|part| match part {
                            ProjectedPart::Text(text) => Some(text.text.as_str()),
                            _ => None,
                        })
                        .collect::<String>();
                    let index = settled_activities.len();
                    settled_activities.push_back(new_streaming_activity_entry(
                        NewStreamingActivityEntryArgs {
                            request_id: request_id.clone(),
                            profile_label: profile_label(transcript, message.agent_id.as_deref()),
                            model_id: String::new(),
                            provider_id: String::new(),
                            user_message: Some(UserMessageSubmittedEvent {
                                request_id: request_id.as_str().into(),
                                text,
                            }),
                            user_timestamp: None,
                            request_data: None,
                            transcript_text: String::new(),
                            first_seq: message.provenance.first_seq,
                            first_mono_ms: message.provenance.first_seq,
                        },
                    ));
                    activity_by_request.insert(request_id.clone(), index);
                    Some(index)
                }
                ProjectedMessageRole::Assistant => {
                    let index = activity_by_request
                        .get(&request_id)
                        .copied()
                        .unwrap_or_else(|| {
                            let index = settled_activities.len();
                            settled_activities.push_back(new_streaming_activity_entry(
                                NewStreamingActivityEntryArgs {
                                    request_id: request_id.clone(),
                                    profile_label: profile_label(
                                        transcript,
                                        message.agent_id.as_deref(),
                                    ),
                                    model_id: String::new(),
                                    provider_id: String::new(),
                                    user_message: None,
                                    user_timestamp: None,
                                    request_data: None,
                                    transcript_text: String::new(),
                                    first_seq: message.provenance.first_seq,
                                    first_mono_ms: message.provenance.first_seq,
                                },
                            ));
                            activity_by_request.insert(request_id.clone(), index);
                            index
                        });
                    Some(index)
                }
                ProjectedMessageRole::System => None,
            };

            if let Some(index) = activity_index {
                let activity = &mut settled_activities[index];
                activity.last_seq = message.provenance.last_seq;
                activity.last_mono_ms = message.provenance.last_seq;
                activity.status = activity_status(message.state);
                if let Some(provider) = message.provider.as_ref() {
                    apply_message_provider_metadata(activity, provider);
                }
                if message.role != ProjectedMessageRole::Assistant {
                    continue;
                }
                for part in &message.parts {
                    apply_message_part(
                        activity,
                        part,
                        &mut pending_permissions,
                        &mut orchestration_tasks,
                        &mut turn_terminals,
                        message.agent_id.as_deref(),
                        &request_id,
                    );
                }
                continue;
            }
            for part in &message.parts {
                if let (ProjectedPart::Permission(permission), Some(index)) = (
                    part,
                    message
                        .request_id
                        .as_ref()
                        .and_then(|id| activity_by_request.get(id.as_str()))
                        .copied(),
                ) {
                    add_permission(
                        &mut settled_activities[index],
                        permission,
                        &mut pending_permissions,
                    );
                    continue;
                }
                if let (ProjectedPart::ToolCall(tool), Some(activity)) =
                    (part, settled_activities.back_mut())
                {
                    activity.tool_calls.push(tool_entry(tool));
                    activity.last_seq = activity.last_seq.max(tool.provenance.last_seq);
                    continue;
                }
                apply_system_part(
                    part,
                    &mut pending_permissions,
                    &mut orchestration_tasks,
                    &mut turn_terminals,
                    message.agent_id.as_deref(),
                    message.request_id.as_ref().map(|id| id.as_str()),
                );
            }
        }

        let (latest_request_budget, provider_context_usage) =
            apply_canonical_provider_presentation(events, transcript, &mut settled_activities);
        mark_user_only_activities(&mut settled_activities, from);
        apply_canonical_background_notifications(
            events,
            transcript,
            &mut settled_activities,
            &mut orchestration_tasks,
        );
        apply_canonical_stale_detections(events, &mut orchestration_tasks);
        apply_canonical_edits(events, &mut settled_activities);

        merge_presentation_enrichment(&mut settled_activities, &presentation_enrichment);
        self.restore_uncommitted_assistant_suffixes(
            &presentation_enrichment,
            &mut settled_activities,
        );
        merge_orchestration_presentation(&mut orchestration_tasks, &presentation_orchestration);
        let mut activities = settled_activities;
        apply_turn_terminals(
            &mut activities,
            &turn_terminals,
            &mut self.completed_turn_request_ids,
            &mut self.terminal_elapsed_ms,
        );
        for activity in &mut activities {
            let has_active_turn_task = orchestration_tasks.values().any(|task| {
                !task.state.is_terminal()
                    && task
                        .queue_key
                        .as_deref()
                        .is_some_and(|queue_key| queue_key.starts_with("provider_model:"))
                    && (task.request_id.as_deref() == Some(activity.request_id.as_str())
                        || task.child_request_id.as_deref() == Some(activity.request_id.as_str()))
            });
            if has_active_turn_task && activity.status == ActivityStatus::Done {
                activity.status = ActivityStatus::Streaming;
            }
        }
        self.run_terminal_seen = run_summary.status != harness_core::proj::RunStatus::Running;
        apply_run_status(&mut activities, run_summary);
        self.activities = if from == 0 {
            activities
        } else {
            prefix.extend(activities);
            prefix
        };
        if from == 0 || latest_request_budget.is_some() {
            self.latest_request_budget = latest_request_budget;
        }
        if provider_context_usage.is_some()
            || self
                .events()
                .any(|event| matches!(event.payload, EventV1::ConversationRewound(_)))
        {
            self.active_context_usage = provider_context_usage;
        }
        self.pending_permissions = pending_permissions;
        self.orchestration_tasks = orchestration_tasks;
        let checkpoint = transcript.compaction_checkpoints.last().cloned();
        self.enforce_orchestration_retention();
        self.rebuild_compaction_presentation(checkpoint.as_ref());
        if self.compaction_status.is_none() {
            self.rebuild_legacy_compaction_presentation(legacy_compaction.as_ref());
        }
        let trimmed = self.transcript_trimmed_count;
        self.enforce_transcript_memory_cap();
        self.transcript_delta = if from == 0 || self.transcript_trimmed_count != trimmed {
            ProjectionDelta::FullRebuild
        } else {
            ProjectionDelta::Activity { index: from }
        };
    }
    fn restore_uncommitted_assistant_suffixes(
        &self,
        presentation_enrichment: &VecDeque<ActivityEntry>,
        settled_activities: &mut VecDeque<ActivityEntry>,
    ) {
        // A provider finish or another durable tool update can settle before
        // the assistant commit. Keep its live suffix on screen until that
        // commit replaces it; otherwise every tool below it jumps up and back.
        for (request_id, transient) in &self.transient_assistants {
            let Some(previous) = presentation_enrichment.iter().find(|activity| {
                activity
                    .request_data
                    .as_ref()
                    .is_some_and(|request| request.request_id.as_str() == request_id)
            }) else {
                continue;
            };
            let Some(activity) = settled_activities
                .iter_mut()
                .find(|activity| activity.request_id == previous.request_id)
            else {
                continue;
            };
            if let Some(text) = previous.transcript_text.get(transient.text_start..) {
                activity.transcript_text.push_str(text);
            }
            if let Some(reasoning) = previous.thinking_text.get(transient.reasoning_start..) {
                activity.thinking_text.push_str(reasoning);
            }
            for tool in &previous.tool_calls {
                if transient.tool_call_ids.contains(&tool.tool_call_id)
                    && !activity
                        .tool_calls
                        .iter()
                        .any(|existing| existing.tool_call_id == tool.tool_call_id)
                {
                    activity.tool_calls.push(tool.clone());
                }
            }
        }
    }
}

fn apply_run_status(
    activities: &mut VecDeque<ActivityEntry>,
    summary: &harness_core::proj::RunSummary,
) {
    let Some(activity) = activities.back_mut() else {
        return;
    };
    match summary.status {
        harness_core::proj::RunStatus::Failed => {
            activity.status = ActivityStatus::Error;
            activity.error_message.clone_from(&summary.last_error);
        }
        harness_core::proj::RunStatus::Finished if activity.status == ActivityStatus::Streaming => {
            activity.status = ActivityStatus::Done;
        }
        harness_core::proj::RunStatus::Running | harness_core::proj::RunStatus::Finished => {}
    }
}

fn apply_message_provider_metadata(
    activity: &mut ActivityEntry,
    provider: &harness_core::transcript_projection::ProjectedProviderMessageMetadata,
) {
    activity.provider_id = provider.provider_id.clone().unwrap_or_default();
    activity.model_id = provider.model_id.clone().unwrap_or_default();
    activity.request_data =
        provider
            .provider_request_id
            .as_ref()
            .map(|id| ProviderRequestStartedEvent {
                request_id: id.as_str().into(),
                provider_id: activity.provider_id.clone(),
                model_id: activity.model_id.clone(),
                prompt_summary: provider.prompt_summary.clone().unwrap_or_default(),
                request_digest: provider.request_digest.clone().unwrap_or_default(),
                metadata: None,
            });
}

fn mark_user_only_activities(activities: &mut VecDeque<ActivityEntry>, from: usize) {
    for (index, activity) in activities.iter_mut().enumerate() {
        let is_user_only = activity.user_message.is_some()
            && activity.request_data.is_none()
            && activity.transcript_text.is_empty()
            && activity.tool_calls.is_empty();
        if is_user_only {
            activity.status = if from == 0 && index == 0 {
                ActivityStatus::Streaming
            } else {
                ActivityStatus::Queued
            };
        }
    }
}
