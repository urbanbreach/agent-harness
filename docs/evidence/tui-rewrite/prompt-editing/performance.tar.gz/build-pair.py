from pathlib import Path
import subprocess
out=Path(__file__).resolve().parent
source=Path('crates/harness-tui/src/app/composer_editing.rs')
candidate=source.read_bytes()
try:
 source.write_bytes((out/'before.rs').read_bytes())
 subprocess.run(['python3',str(out/'build.py'),'before'],check=True)
finally:
 source.write_bytes(candidate)
subprocess.run(['python3',str(out/'build.py'),'candidate'],check=True)
